using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using StudentValidation.Models;

namespace StudentValidation.Controllers
{
    public class StudentController : Controller
    {
        private static readonly List<Student> listStudents = new();

        private void LoadData()
        {
            ViewBag.AllGenders = Enum.GetValues<Gender>()
                .Select(g => new SelectListItem
                {
                    Text = g.ToString(),
                    Value = ((int)g).ToString()
                }).ToList();

            ViewBag.AllBranches = new List<SelectListItem>
            {
                new SelectListItem { Text = "IT", Value = "1" },
                new SelectListItem { Text = "BE", Value = "2" },
                new SelectListItem { Text = "IS", Value = "3" },
                new SelectListItem { Text = "EE", Value = "4" }
            };
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View(listStudents);
        }

        [HttpGet]
        public IActionResult Create()
        {
            LoadData();
            return View(new Student());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Student s)
        {
            if (ModelState.IsValid)
            {
                s.Id = listStudents.Count == 0 ? 1 : listStudents.Max(x => x.Id) + 1;
                listStudents.Add(s);
                return RedirectToAction(nameof(Index));
            }

            LoadData();
            return View(s);
        }
    }
}
