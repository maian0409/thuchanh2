HUONG DAN CHAY PROJECT BÀI THỰC HÀNH 3

1. Giai nen StudentValidation.zip.
2. Mo file Bài thực hành 3.csproj bang Visual Studio 2022/2026.
3. Dam bao da cai dat .NET 8 SDK va workload ASP.NET and web development.
4. Chay bang Ctrl + F5.
5. Trang mac dinh la /Student/Index. Chon "Them sinh vien" de thu validation.

CAC RANG BUOC
- Ho ten: bat buoc, tu 4 den 100 ky tu.
- Email: bat buoc, phai co duoi gmail.com.
- Mat khau: it nhat 8 ky tu, co chu hoa, chu thuong, chu so va ky tu dac biet; khong co khoang trang.
- Nganh hoc, gioi tinh: bat buoc chon.
- Dia chi: bat buoc.
- Ngay sinh: tu 01/01/1963 den 31/12/2005.
- Diem: bat buoc, tu 0 den 10.

LUU Y
Du lieu sinh vien duoc luu trong List trong bo nho, khong luu vao SQL Server va se mat khi khoi dong lai ung dung.
Project su dung Bootstrap CDN; can co Internet de hien thi giao dien Bootstrap.
